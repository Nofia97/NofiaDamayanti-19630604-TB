-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 09 Jan 2022 pada 05.33
-- Versi server: 10.4.14-MariaDB
-- Versi PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_tiket_pesawat`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `pesawat`
--

CREATE TABLE `pesawat` (
  `kode_pesawat` varchar(50) NOT NULL,
  `nama_pesawat` varchar(50) NOT NULL,
  `no_kursi` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pesawat`
--

INSERT INTO `pesawat` (`kode_pesawat`, `nama_pesawat`, `no_kursi`) VALUES
('001', 'Lion Air', 'L23'),
('002', 'Garuda', 'G20'),
('003', 'Lion Air', 'L40'),
('004', 'Lion Air', 'L30'),
('005', 'Garuda', 'G22');

-- --------------------------------------------------------

--
-- Struktur dari tabel `rute`
--

CREATE TABLE `rute` (
  `kode_rute` varchar(15) NOT NULL,
  `nama_rute` varchar(50) NOT NULL,
  `kelas` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `rute`
--

INSERT INTO `rute` (`kode_rute`, `nama_rute`, `kelas`) VALUES
('001', 'Banjarmasin - Bali', 'Satu'),
('002', 'Banjarmasin - Jakarta', 'Ekonomi'),
('003', 'Banjarmasin - Bandung', 'Bisnis'),
('004', 'Banjarmasi - surabaya', 'Perjalanan'),
('005', 'Banjarmasin - palembang', 'Ekonomi');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tiket`
--

CREATE TABLE `tiket` (
  `id_tiket` varchar(15) NOT NULL,
  `nama_rute` varchar(50) NOT NULL,
  `kode_pesawat` varchar(50) NOT NULL,
  `tanggal_berangkat` text NOT NULL,
  `kelas` varchar(15) NOT NULL,
  `jumlah` int(15) NOT NULL,
  `bayar` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tiket`
--

INSERT INTO `tiket` (`id_tiket`, `nama_rute`, `kode_pesawat`, `tanggal_berangkat`, `kelas`, `jumlah`, `bayar`) VALUES
('001', 'Banjarmasin - Bali', 'Lion Air', '30-01-22', 'Satu', 1, 1200000),
('002', 'Banjarmasin - Jakarta', 'Garuda', '20-02-22', 'Ekonomi', 2, 1600000),
('003', 'Banjarmasin - Bandung', 'Lion Air', '23-01-22', 'Bisnis', 2, 2000000),
('004', 'Banjarmasi - surabaya', 'Lion Air', '28-02-22', 'Perjalanan', 2, 1200000),
('005', 'Banjarmasin - palembang', 'Garuda', '30-08-23', 'Ekonomi', 3, 2400000);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
